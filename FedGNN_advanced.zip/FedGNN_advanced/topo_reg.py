# topo_reg.py
"""
A differentiable surrogate for topological regularization.

This implementation uses pairwise distances of node embeddings and penalizes
excessively small pairwise distances via a smooth function, encouraging
the embedding to preserve some topological separation.

It is NOT a substitute for full persistent homology, but is a differentiable,
cheap proxy that helps avoid collapsed embeddings.
"""

import torch
import torch.nn.functional as F

def topo_penalty(embeddings: torch.Tensor, margin: float = 1.0, k: int = None):
    """
    embeddings: (N, d) node embeddings
    margin: the desired separation scale; distances << margin are penalized
    k: if set, only consider k-nearest neighbors for each node (saves compute)
    returns: scalar tensor (differentiable)
    """
    # embeddings shape (N, D)
    if embeddings.dim() == 1:
        embeddings = embeddings.unsqueeze(0)
    n = embeddings.size(0)
    if n <= 1:
        return torch.tensor(0.0, device=embeddings.device)

    # pairwise squared distances
    # D_ij = ||x_i - x_j||^2
    # Use efficient computation
    x = embeddings
    x2 = (x ** 2).sum(dim=1, keepdim=True)  # (N,1)
    D2 = x2 + x2.t() - 2.0 * (x @ x.t())  # (N,N)
    D2 = torch.clamp(D2, min=0.0)
    D = torch.sqrt(D2 + 1e-12)

    # ignore diagonal
    mask = ~torch.eye(n, dtype=torch.bool, device=embeddings.device)

    # Optionally restrict to k nearest neighbors per node
    if k is not None and k > 0 and k < n:
        # for each row, find threshold distance to keep k nearest (not counting self)
        D_masked = D.clone()
        D_masked[~mask] = float('inf')
        # kth smallest
        kth_vals, _ = torch.kthvalue(D_masked, k, dim=1)  # (N,)
        # Build neighbor mask
        knn_mask = D <= kth_vals.unsqueeze(1)
        effective_mask = mask & knn_mask
    else:
        effective_mask = mask

    # penalize small distances: use smooth penalty = sum( exp( - (D / margin) ) )
    # this penalizes distances much smaller than margin
    scaled = D / (margin + 1e-12)
    penal = torch.exp(-scaled) * effective_mask.float()
    score = penal.sum() / max(1, effective_mask.float().sum())

    # return scalar (higher means more collapsed — we want to minimize)
    return score
