# compression.py
"""
Simple compression helpers for model deltas.

Available strategies:
- none: no change (keep torch tensors)
- fp16: cast to float16 for transmission (lossy)
- gzip: convert numpy arrays to bytes and gzip compress (example)
"""

import io, gzip
import torch
import numpy as np
from typing import Dict, Any

def to_numpy_dict(tdict: Dict[str, torch.Tensor]):
    return {k: v.cpu().numpy() for k, v in tdict.items()}

def from_numpy_dict(ndict: Dict[str, Any], device='cpu'):
    return {k: torch.tensor(v, device=device) for k, v in ndict.items()}

def compress_fp16(delta: Dict[str, torch.Tensor]):
    """Return a dict of float16 numpy arrays (smaller)."""
    return {k: v.cpu().half().numpy() for k, v in delta.items()}

def decompress_fp16(data: Dict[str, Any], device='cpu'):
    return {k: torch.tensor(v, dtype=torch.float16, device=device).float() for k, v in data.items()}

def compress_gzip_numpy(delta: Dict[str, torch.Tensor]) -> bytes:
    # pack using numpy savez into a bytes buffer then gzip
    buf = io.BytesIO()
    npdict = {k: v.cpu().numpy() for k, v in delta.items()}
    # np.savez_compressed writes compressed .npz; we can reuse it (no additional gzip)
    np.savez_compressed(buf, **npdict)
    raw = buf.getvalue()
    out = gzip.compress(raw)
    return out

def decompress_gzip_numpy(raw_bytes: bytes):
    decompressed = gzip.decompress(raw_bytes)
    buf = io.BytesIO(decompressed)
    npz = np.load(buf, allow_pickle=False)
    return {k: npz[k] for k in npz.files}
