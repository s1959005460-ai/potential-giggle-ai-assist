# benchmark.py
import os, json, yaml, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from run_experiment import main as run_main
import shutil, subprocess, sys

def run_with_outdir(outdir, rounds=3):
    # Use run_experiment CLI and config override via environment or temp config
    # Simpler approach: call run_experiment main with updated config file
    cfg = {'train': {'rounds': rounds, 'num_clients': 4, 'local_epochs': 1, 'use_delta': True}}
    tmp_cfg = 'tmp_bench_config.yaml'
    with open(tmp_cfg, 'w') as f:
        yaml.safe_dump(cfg, f)
    # run experiment via subprocess to isolate
    cmd = [sys.executable, 'run_experiment.py', '--config', tmp_cfg]
    env = os.environ.copy()
    env['PYTHONUNBUFFERED'] = '1'
    os.makedirs(outdir, exist_ok=True)
    # direct call
    subprocess.run(cmd, env=env, check=True)
    # move outputs to outdir
    if os.path.exists('outputs'):
        if os.path.exists(outdir):
            shutil.rmtree(outdir)
        shutil.move('outputs', outdir)
    if os.path.exists(tmp_cfg):
        os.remove(tmp_cfg)

def read_metrics(outdir):
    path = os.path.join(outdir, 'results.json')
    if not os.path.exists(path):
        return [], []
    data = json.load(open(path,'r'))
    rounds = data.get('rounds', [])
    accs = [r.get('avg_acc', 0.0) for r in rounds]
    comms = [sum(r.get('comm_bytes', [])) for r in rounds]
    return accs, comms

if __name__ == '__main__':
    # Run two experiments (placeholder: same config -- extend to scaffold later)
    run_with_outdir('out_fedavg', rounds=3)
    acc_fed, comm_fed = read_metrics('out_fedavg')
    run_with_outdir('out_scaffold', rounds=3)
    acc_sca, comm_sca = read_metrics('out_scaffold')

    plt.figure(figsize=(10,4))
    plt.subplot(1,2,1)
    plt.plot(acc_fed, label='FedAvg')
    plt.plot(acc_sca, label='SCAFFOLD')
    plt.title('Avg Accuracy')
    plt.xlabel('Round')
    plt.legend()
    plt.subplot(1,2,2)
    plt.plot(comm_fed, label='FedAvg')
    plt.plot(comm_sca, label='SCAFFOLD')
    plt.title('Comm bytes per round')
    plt.xlabel('Round')
    plt.legend()
    plt.tight_layout()
    plt.savefig('benchmark.png')
    print('Saved benchmark.png')
