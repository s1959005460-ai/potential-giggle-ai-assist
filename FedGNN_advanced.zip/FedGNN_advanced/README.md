# FedGNN Project

完整联邦图神经网络示例，包含：
- Non-IID 联邦训练
- 多轮迭代训练
- 后端 API
- 前端可视化
