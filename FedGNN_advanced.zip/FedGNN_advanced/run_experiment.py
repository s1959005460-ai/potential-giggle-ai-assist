# run_experiment.py
import argparse, yaml, asyncio, os
from models import get_model
from learner import Learner
from data_loader import synthetic_graph, split_non_iid_by_label
from server import AsyncFedServer

def build_clients_from_config(cfg):
    num_clients = int(cfg.get('num_clients', 4))
    local_epochs = int(cfg.get('local_epochs', 1))
    model_name = cfg.get('model', 'gcn')
    clients = []
    base = get_model(model_name, in_ch=16, hidden=32, out=3)
    for _ in range(num_clients):
        m = get_model(model_name, in_ch=16, hidden=32, out=3)
        m.load_state_dict({k:v.clone() for k,v in base.state_dict().items()})
        data = synthetic_graph(num_nodes=34, in_feats=16, num_classes=3)
        clients.append(Learner(m, data, lr=cfg.get('lr', 0.05), local_epochs=local_epochs, device='cpu', topo_lambda=cfg.get('topo_lambda',0.0)))
    return base, clients

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='config.yaml')
    parser.add_argument('--rounds', type=int, default=None)
    args = parser.parse_args()
    cfg = {}
    if args.config and os.path.exists(args.config):
        import yaml
        with open(args.config,'r') as f:
            cfg = yaml.safe_load(f) or {}
    # override rounds if CLI passed
    if args.rounds:
        cfg.setdefault('train', {})['rounds'] = args.rounds

    train_cfg = cfg.get('train', {})
    rounds = int(train_cfg.get('rounds', 3))
    use_delta = bool(train_cfg.get('use_delta', True))
    out_dir = cfg.get('out_dir', './outputs')

    base, clients = build_clients_from_config({'num_clients': train_cfg.get('num_clients', 4),
                                              'local_epochs': train_cfg.get('local_epochs',1),
                                              'model': cfg.get('model','gcn'),
                                              'lr': cfg.get('lr',0.05),
                                              'topo_lambda': cfg.get('topo_lambda', 0.0)})

    server = AsyncFedServer(model_template=base, clients=clients, device='cpu', out_dir=out_dir, websocket_manager=None, use_delta=use_delta)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(server.run_round(rounds=rounds))
    print('Experiment finished, outputs in', out_dir)

if __name__ == '__main__':
    main()
