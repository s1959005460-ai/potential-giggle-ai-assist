# server.py
import asyncio
import copy
import json
import os
import time
import logging
import torch

logger = logging.getLogger(__name__)

class AsyncFedServer:
    def __init__(self, model_template: torch.nn.Module, clients: list, device='cpu',
                 scaffold=False, out_dir='./outputs', websocket_manager=None, use_delta=True):
        self.device = device
        self.global_model = copy.deepcopy(model_template).to(device)
        self.clients = clients
        self.scaffold = scaffold
        self.out_dir = out_dir
        self.websocket_manager = websocket_manager
        self.use_delta = use_delta

    def aggregate_deltas(self, client_deltas, weights=None):
        """Aggregate deltas (dict of CPU tensors) and apply to global_model."""
        if not client_deltas:
            raise ValueError("No deltas provided")
        if weights is None:
            weights = [1.0/len(client_deltas)] * len(client_deltas)
        # global state (on device)
        global_state = self.global_model.state_dict()
        agg_delta = {k: torch.zeros_like(v).to(self.device) for k, v in global_state.items()}
        for delta, w in zip(client_deltas, weights):
            for k, v in delta.items():
                agg_delta[k] += v.to(self.device) * w
        # apply aggregated delta
        new_state = {}
        for k, v in global_state.items():
            new_state[k] = (v.to(self.device) + agg_delta[k]).to(self.device)
        self.global_model.load_state_dict(new_state)
        return agg_delta

    async def run_round(self, rounds=1, clients_per_round=None):
        history = []
        for r in range(rounds):
            round_start = time.perf_counter()
            sel = self.clients if clients_per_round is None else self.clients[:clients_per_round]
            tasks = []
            for c in sel:
                # send CPU global_state snapshot
                gs = {k: v.cpu() for k, v in self.global_model.state_dict().items()}
                if asyncio.iscoroutinefunction(c.train_local):
                    tasks.append(c.train_local(gs))
                else:
                    async def run_sync(cl, gs):
                        return cl.train_local(gs)
                    tasks.append(run_sync(c, gs))
            results = await asyncio.gather(*tasks)
            client_deltas = []
            client_losses = []
            comm_sizes = []
            for res in results:
                delta = res.get('delta', None)
                if delta is None:
                    # back-compat: accept state_dict
                    state = res.get('state_dict')
                    # compute delta = state - global
                    delta = {}
                    gs = {k: v.cpu() for k, v in self.global_model.state_dict().items()}
                    for k in gs.keys():
                        delta[k] = (state[k] - gs[k])
                client_deltas.append({k: v for k, v in delta.items()})
                client_losses.append(res.get('train_loss', None))
                size = sum((v.numel() * v.element_size()) for v in delta.values())
                comm_sizes.append(int(size))
            # aggregate deltas by equal weight
            weights = [1.0] * len(client_deltas)
            norm_weights = [w / sum(weights) for w in weights]
            agg_delta = self.aggregate_deltas(client_deltas, norm_weights)
            # evaluate global on clients
            evals = []
            for c in self.clients:
                try:
                    acc = self.evaluate_global_on_client(c)
                except Exception:
                    acc = None
                evals.append(acc)
            avg_loss = sum([x for x in client_losses if x is not None]) / max(1, len([x for x in client_losses if x is not None]))
            avg_acc = sum([x for x in evals if x is not None]) / max(1, len([x for x in evals if x is not None]))
            elapsed = time.perf_counter() - round_start
            round_info = {
                'round': r,
                'avg_loss': float(avg_loss),
                'avg_acc': float(avg_acc),
                'times': {'round_seconds': elapsed},
                'comm_bytes': comm_sizes
            }
            history.append(round_info)
            os.makedirs(self.out_dir, exist_ok=True)
            with open(os.path.join(self.out_dir, 'results.json'), 'w') as f:
                json.dump({'rounds': history}, f, indent=2, default=float)
            # websocket push
            if self.websocket_manager:
                try:
                    await self.websocket_manager.send_message(json.dumps({'type':'round_info', 'payload': round_info}))
                except Exception:
                    logger.exception("Failed to push round_info")
        return self.global_model.state_dict()

    def evaluate_global_on_client(self, client):
        self.global_model.eval()
        tmp = copy.deepcopy(client.model)
        tmp.load_state_dict(self.global_model.state_dict())
        tmp.to(self.device)
        tmp.eval()
        with torch.no_grad():
            x = client.data['x'].to(self.device)
            adj = client.data.get('adj', None)
            out = tmp(x, adj)
            preds = out.argmax(dim=1)
            mask = client.data.get('train_mask', None)
            if mask is None:
                mask = torch.ones_like(preds, dtype=torch.bool).to(self.device)
            else:
                mask = mask.to(self.device)
            if mask.sum() == 0:
                return 0.0
            acc = (preds[mask] == client.data['y'].to(self.device)[mask]).float().mean().item()
        return acc
