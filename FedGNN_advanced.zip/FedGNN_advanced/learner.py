# learner.py
import torch
import torch.nn as nn
import torch.optim as optim
from client_abc import FederatedClient

# try import topo_reg
try:
    from topo_reg import topo_penalty
except Exception:
    def topo_penalty(x, margin=1.0, k=None):
        return torch.tensor(0.0, device=x.device)

class Learner(FederatedClient):
    """
    Learner that trains locally and returns parameter delta (local - global).
    data expected: {'x','adj' or 'edge_index', 'y', 'train_mask'}
    """
    def __init__(self, model: nn.Module, data: dict, lr=0.01, local_epochs=1, device='cpu', use_scaffold=False, topo_lambda=0.0):
        self.device = device
        self.model = model.to(device)
        self.data = data
        self.lr = lr
        self.local_epochs = local_epochs
        self.use_scaffold = use_scaffold
        self.topo_lambda = topo_lambda

    def train_one_epoch(self, optimizer, loss_fn):
        self.model.train()
        x = self.data['x'].to(self.device)
        adj = self.data.get('adj', None)
        out = self.model(x, adj)
        mask = self.data.get('train_mask', torch.ones(out.size(0), dtype=torch.bool, device=self.device)).to(self.device)
        if mask.sum() == 0:
            return 0.0
        loss = loss_fn(out[mask], self.data['y'].to(self.device)[mask])
        # topo reg on embedding
        if self.topo_lambda and self.topo_lambda > 0:
            emb = self.model.embed(x, adj)
            topo = topo_penalty(emb[mask], margin=1.0, k=8)
            loss = loss + self.topo_lambda * topo
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        return float(loss.item())

    def train_local(self, global_state: dict, c_global=None):
        # load global
        self.model.load_state_dict({k: v.to(self.device) for k,v in global_state.items()})
        optimizer = optim.SGD(self.model.parameters(), lr=self.lr)
        loss_fn = nn.NLLLoss()
        last_loss = None
        for _ in range(self.local_epochs):
            last_loss = self.train_one_epoch(optimizer, loss_fn)
        # compute delta (cpu tensors for serialization)
        local_state = self.model.state_dict()
        delta = {}
        for k in local_state.keys():
            delta[k] = (local_state[k].cpu() - global_state[k].cpu())
        res = {'delta': delta, 'train_loss': last_loss}
        return res

    def evaluate(self, model_state_dict=None, mask=None):
        if model_state_dict is not None:
            self.model.load_state_dict({k:v for k,v in model_state_dict.items()})
        self.model.eval()
        with torch.no_grad():
            x = self.data['x'].to(self.device)
            adj = self.data.get('adj', None)
            out = self.model(x, adj)
            preds = out.argmax(dim=1)
            mask = self.data.get('train_mask', torch.ones(preds.size(0), dtype=torch.bool)).to(self.device) if mask is None else mask.to(self.device)
            if mask.sum() == 0:
                return 0.0
            acc = (preds[mask] == self.data['y'].to(self.device)[mask]).float().mean().item()
        return acc
