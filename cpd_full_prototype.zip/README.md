Critical Point Detection - Single-machine Prototype

This archive contains a runnable single-machine prototype of the GNN + federated critical-point detection system.
It's simplified for local experimentation and includes:
  - FAST (light scoring)
  - VERIFY (eigsh with fallback)
  - DECIDE (fusion)
  - LEARN (local learner with PyTorch fallback)
  - Simple Federated aggregator (FedAvg)
  - Utilities and a smoke test

How to run:
  1. (Optional) create a virtualenv:
     python -m venv venv
     source venv/bin/activate
  2. Install minimal deps:
     pip install -r requirements.txt
  3. Run a short demo:
     python run_pipeline.py --iterations 5
  4. Run tests:
     pytest tests/test_pipeline.py -q

Notes:
  - This is a prototype for development only. It does NOT include Kafka/Flink/secure aggregation/production TLS.
  - Integration points are commented in the code.
