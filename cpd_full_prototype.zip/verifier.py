import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import eigsh
from utils.graph_utils import get_k_hop_subgraph

class Verifier:
    def __init__(self, num_eigenvectors=2, max_nodes_full=5000):
        self.num_eigenvectors = num_eigenvectors
        self.max_nodes_full = max_nodes_full
        self.prev_gap = None

    def verify_local(self, graph, center_nodes, k=2):
        sub = get_k_hop_subgraph(graph, center_nodes, k=k)
        n = sub.number_of_nodes()
        if n==0:
            return {'gap':0.0, 'svals':[], 'trend':[], 'incremental':False}
        A = nx_to_sparse(sub)
        try:
            if n <= self.max_nodes_full:
                k_eig = min(self.num_eigenvectors, n-1)
                vals, vecs = eigsh(A, k=k_eig, which='LM')
                vals = np.sort(vals)[::-1]
                gap = float(vals[0] - (vals[1] if len(vals)>1 else 0.0))
                trend = []
                if self.prev_gap is not None:
                    trend = [gap - self.prev_gap]
                self.prev_gap = gap
                return {'gap':gap, 'svals':vals.tolist(), 'trend':trend, 'incremental':False}
            else:
                # sampled fallback
                sampled = sampled_submatrix(A, sample_rate=0.1)
                k_eig = min(self.num_eigenvectors, sampled.shape[0]-1)
                vals, vecs = eigsh(sampled, k=k_eig, which='LM')
                vals = np.sort(vals)[::-1]
                gap = float(vals[0] - (vals[1] if len(vals)>1 else 0.0))
                return {'gap':gap, 'svals':vals.tolist(), 'trend':[], 'incremental':False}
        except Exception:
            return {'gap':0.0, 'svals':[], 'trend':[], 'incremental':False}

def nx_to_sparse(g):
    import networkx as nx
    nodes = list(g.nodes())
    idx = {n:i for i,n in enumerate(nodes)}
    rows, cols, data = [], [], []
    for u,v in g.edges():
        rows.extend([idx[u], idx[v]])
        cols.extend([idx[v], idx[u]])
        data.extend([1.0, 1.0])
    return sp.csr_matrix((data,(rows,cols)), shape=(len(nodes), len(nodes)))

def sampled_submatrix(A, sample_rate=0.1):
    import numpy as np
    n = A.shape[0]
    c = max(2, int(n * sample_rate))
    idx = np.random.choice(n, size=c, replace=False)
    return A[idx,:][:,idx]
