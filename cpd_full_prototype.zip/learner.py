import numpy as np
try:
    import torch
    import torch.nn as nn
    TORCH=True
except Exception:
    TORCH=False

class Learner:
    def __init__(self, input_dim=6, hidden_dim=32, lr=0.01):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.lr = lr
        if TORCH:
            self.model = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim,1))
            self.opt = torch.optim.SGD(self.model.parameters(), lr=lr)
            self.loss_fn = nn.BCEWithLogitsLoss()
        else:
            self.model = None

    def get_model_params(self):
        if TORCH:
            return [p.detach().cpu().numpy() for p in self.model.parameters()]
        else:
            return None

    def get_model(self):
        return self.model

    def set_model_params(self, params):
        if not TORCH or params is None:
            return False
        import torch
        for p, new in zip(self.model.parameters(), params):
            p.data = torch.from_numpy(new).to(p.device)
        return True

    def update(self, X, y, epochs=1):
        if not TORCH:
            return float('nan')
        import torch
        self.model.train()
        X_t = torch.from_numpy(X)
        y_t = torch.from_numpy(y)
        for _ in range(epochs):
            self.opt.zero_grad()
            out = self.model(X_t).squeeze()
            loss = self.loss_fn(out, y_t.squeeze())
            loss.backward()
            self.opt.step()
        return float(loss.item())
