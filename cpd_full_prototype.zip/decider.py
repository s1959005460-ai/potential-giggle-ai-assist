def decide(fast_result, verify_result):
    w_business = 0.4
    w_spectral = 0.3
    w_topo = 0.3
    business = fast_result.get('score', 0.0)
    spectral = verify_result.get('gap', 0.0) if verify_result else 0.0
    topo = fast_result.get('topo_features', {}).get('betti_ratio', 0.0)
    combined = w_business*business + w_spectral*spectral + w_topo*topo
    action = 'no_op'
    if combined > 0.6:
        action = 'high_alert'
    elif combined > 0.3:
        action = 'medium_alert'
    return {'action':action, 'combined_score':combined}
