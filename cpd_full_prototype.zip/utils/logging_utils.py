import logging, sys, json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'func': record.funcName,
            'line': record.lineno
        }
        return json.dumps(log)

def setup_logger(name, level=logging.INFO, json_format=False):
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        h = logging.StreamHandler(sys.stdout)
        if json_format:
            h.setFormatter(JSONFormatter())
        else:
            h.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        logger.addHandler(h)
    return logger
