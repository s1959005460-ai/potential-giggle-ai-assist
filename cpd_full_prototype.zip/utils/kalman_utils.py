import numpy as np

class BatchKalmanFilter:
    def __init__(self, state_dim=1, process_noise=1e-3, measurement_noise=1e-2):
        self.state_dim = state_dim
        self.F = np.eye(state_dim)
        self.Q = np.eye(state_dim) * process_noise
        self.H = np.eye(state_dim)
        self.R = np.eye(state_dim) * measurement_noise
        self.P = np.eye(state_dim)
        self.state = None

    def init_state(self, measurement):
        self.state = measurement.reshape(-1,1)
        self.P = np.eye(self.state_dim)

    def update(self, measurements):
        if self.state is None:
            self.init_state(measurements[0])
        n = measurements.shape[0]
        states = np.zeros((n, self.state_dim))
        for i,z in enumerate(measurements):
            z = z.reshape(-1,1)
            state_pred = self.F @ self.state
            P_pred = self.F @ self.P @ self.F.T + self.Q
            y = z - self.H @ state_pred
            S = self.H @ P_pred @ self.H.T + self.R
            K = P_pred @ self.H.T @ np.linalg.inv(S)
            self.state = state_pred + K @ y
            self.P = (np.eye(self.state_dim) - K @ self.H) @ P_pred
            states[i] = self.state.flatten()
        return states
