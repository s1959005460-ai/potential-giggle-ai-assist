import networkx as nx
import numpy as np

def sample_nodes(graph, sample_size=1000, strategy='random'):
    nodes = list(graph.nodes())
    if len(nodes) <= sample_size:
        return nodes
    if strategy == 'random':
        return list(np.random.choice(nodes, size=sample_size, replace=False))
    elif strategy == 'degree':
        degs = np.array([d for _,d in graph.degree()])
        probs = degs / degs.sum()
        return list(np.random.choice(nodes, size=sample_size, replace=False, p=probs))
    else:
        return list(np.random.choice(nodes, size=sample_size, replace=False))

def get_k_hop_subgraph(graph, center_nodes, k=2):
    all_nodes = set()
    for n in center_nodes:
        if n in graph:
            nbrs = nx.single_source_shortest_path_length(graph, n, cutoff=k).keys()
            all_nodes.update(nbrs)
    return graph.subgraph(all_nodes).copy()

def calculate_node_features(graph):
    feats = {}
    if graph.number_of_nodes()==0:
        return feats
    # compute pagerank once
    pr = nx.pagerank(graph)
    for n in graph.nodes():
        deg = graph.degree(n)
        cc = nx.clustering(graph, n)
        pagerank = pr.get(n, 0.0)
        feats[n] = np.array([deg, cc, float(pagerank), 0.0, 0.0, 1.0], dtype=np.float32)
    return feats
