import argparse, time
import networkx as nx
import numpy as np
from fast_agent import FastAgent
from verifier import Verifier
from decider import decide as decider_fn
from learner import Learner
from federated.server import FederatedServer
from federated.client import FederatedClient
from utils.logging_utils import setup_logger

logger = setup_logger("cpd_demo", json_format=False)

def main(iterations=5, graph_size=1000):
    p = 0.005 if graph_size >= 2000 else 0.01
    G = nx.erdos_renyi_graph(graph_size, p, seed=42)
    logger.info(f"Graph: nodes={G.number_of_nodes()} edges={G.number_of_edges()}")

    fast = FastAgent()
    verifier = Verifier()
    learner = Learner(input_dim=6, hidden_dim=32)
    fed_server = FederatedServer(model_initializer=learner.get_model_params, num_rounds=10, min_clients=2)
    clients = [FederatedClient(f"client{i}", None, learner.get_model, local_epochs=1) for i in range(2)]

    for it in range(iterations):
        logger.info(f"--- Iteration {it+1}/{iterations} ---")
        nodes = np.random.choice(list(G.nodes()), size=min(200, G.number_of_nodes()), replace=False).tolist()
        fast_result = fast.predict(G, nodes)
        logger.info(f"FAST score={fast_result['score']:.3f} top_k={len(fast_result['top_k_nodes'])}")

        if fast_result['score'] < 0.1:
            decision = decider_fn(fast_result, None)
            logger.info(f"Decision: {decision['action']}")
            time.sleep(0.2)
            continue

        verify_result = verifier.verify_local(G, fast_result['top_k_nodes'])
        decision = decider_fn(fast_result, verify_result)
        logger.info(f"Decision: {decision['action']} combined_score={decision['combined_score']:.3f}")

        if decision['action'] != 'no_op':
            X = np.random.randn(100, 6).astype('float32')
            y = np.random.randint(0,2,(100,1)).astype('float32')
            loss = learner.update(X, y)
            logger.info(f"Learner update loss={loss}")

        # Simulated federated clients training and sending updates
        for c in clients:
            params, n, loss = c.train(fed_server.get_global_model())
            if params is not None:
                fed_server.receive_update(c.client_id, fed_server.current_round, params, n)
        fed_server.try_aggregate()
        time.sleep(0.2)

    logger.info('Demo finished')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--iterations', type=int, default=5)
    parser.add_argument('--graph-size', type=int, default=1000)
    args = parser.parse_args()
    main(iterations=args.iterations, graph_size=args.graph_size)
