def test_smoke():
    # run a short demo import to ensure modules load
    import run_pipeline
    run_pipeline.main(iterations=1, graph_size=200)
    assert True
