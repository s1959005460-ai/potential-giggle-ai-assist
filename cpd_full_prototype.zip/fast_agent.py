import numpy as np
from utils.graph_utils import calculate_node_features

class FastAgent:
    def __init__(self):
        pass

    def predict(self, graph, node_list, top_k=10):
        feats = calculate_node_features(graph)
        X = []
        nodes = []
        for n in node_list:
            if n in feats:
                X.append(feats[n])
                nodes.append(n)
        if len(X)==0:
            return {'score':0.0, 'uncertainty':1.0, 'top_k_nodes':[], 'topo_features':{}}
        X = np.vstack(X)
        scores = X.mean(axis=1)
        uncertainty = float(scores.std())
        idx = np.argsort(-scores)[:top_k]
        top_nodes = [nodes[i] for i in idx]
        return {'score': float(scores.mean()), 'uncertainty':uncertainty, 'top_k_nodes': top_nodes, 'topo_features':{}}
