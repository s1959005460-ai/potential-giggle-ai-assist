import threading

class FederatedServer:
    def __init__(self, model_initializer, num_rounds=10, min_clients=2):
        self.global_model = model_initializer()
        self.num_rounds = num_rounds
        self.min_clients = min_clients
        self.current_round = 0
        self.lock = threading.Lock()
        self.pending = []

    def get_global_model(self):
        return self.global_model

    def receive_update(self, client_id, round_num, update, num_samples):
        with self.lock:
            self.pending.append((client_id, update, num_samples))
        return True

    def try_aggregate(self):
        with self.lock:
            if len(self.pending) >= self.min_clients:
                self._aggregate()
                self.pending = []

    def _aggregate(self):
        total = sum([p[2] for p in self.pending])
        if total == 0:
            return
        # assume update is list of numpy arrays
        num_params = len(self.pending[0][1])
        new = []
        for i in range(num_params):
            s = None
            for (_, upd, n) in self.pending:
                arr = upd[i]
                if s is None:
                    s = arr.astype('float64') * n
                else:
                    s += arr.astype('float64') * n
            new.append((s / float(total)).astype('float32'))
        self.global_model = new
        self.current_round += 1
