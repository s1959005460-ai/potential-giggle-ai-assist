import numpy as np

class FederatedClient:
    def __init__(self, client_id, local_data, model_initializer, local_epochs=1):
        self.client_id = client_id
        self.local_data = local_data
        self.model_initializer = model_initializer
        self.local_epochs = local_epochs
        self.model = None
        self.num_samples = 100

    def train(self, global_model):
        # simulate training: perturb global model
        if global_model is None:
            base = [np.random.randn(3,3).astype('float32'), np.random.randn(3).astype('float32')]
        else:
            base = global_model
        upd = []
        for p in base:
            noise = np.random.randn(*p.shape).astype('float32') * 0.01
            upd.append(p + noise)
        return upd, self.num_samples, float('nan')
