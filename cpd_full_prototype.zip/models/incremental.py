import numpy as np
from scipy.sparse.linalg import eigsh

class SparseIncrementalEigenSolver:
    def __init__(self, num_eigenvectors=2):
        self.num_eigenvectors = num_eigenvectors
        self.eigenvalues = None
        self.eigenvectors = None

    def update(self, A_sparse):
        n = A_sparse.shape[0]
        k = min(self.num_eigenvectors, max(0, n-1))
        if k <= 0:
            return [], []
        vals, vecs = eigsh(A_sparse, k=k, which='LM')
        idx = vals.argsort()[::-1]
        self.eigenvalues = vals[idx]
        self.eigenvectors = vecs[:,idx]
        return self.eigenvalues, self.eigenvectors

    def get_spectral_gap(self):
        if self.eigenvalues is None or len(self.eigenvalues)<2:
            return 0.0
        v = sorted(self.eigenvalues, reverse=True)
        return float(v[0]-v[1])
