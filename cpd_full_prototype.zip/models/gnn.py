try:
    import torch
    import torch.nn as nn
except Exception:
    torch = None
    nn = None

class GNNModel:
    def __init__(self, input_dim, hidden_dim=32, output_dim=1, num_layers=2):
        if torch is None:
            raise RuntimeError("torch not available")
        layers = []
        layers.append(nn.Linear(input_dim, hidden_dim))
        layers.append(nn.ReLU())
        for _ in range(max(0,num_layers-2)):
            layers.append(nn.Linear(hidden_dim, hidden_dim))
            layers.append(nn.ReLU())
        layers.append(nn.Linear(hidden_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def __call__(self, x):
        return self.net(x)

    def parameters(self):
        return self.net.parameters()
